This is a text file, not an OrCAD design.
